//Fikri Aziz Biruni - 2702356362

#include <stdio.h>

int main(){
    int a, b;
    
    printf("Input a & b: ");
    scanf("%d %d", &a, &b);
    
    printf("Penjumlahan: %d\n", a + b);
    printf("Pengurangan: %d\n", a - b);
    printf("Perkalian: %d\n", a * b);
    printf("Pembagian: %d\n", a / b);
    printf("Sisa bagi: %d\n", a % b);
    
    return 0;
}
