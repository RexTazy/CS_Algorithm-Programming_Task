//Fikri Aziz Biruni - 2702356362

#include <stdio.h>

int main(){
    char i;
    
    printf("Enter character: ");
    scanf("%c", &i);
    
    printf("Output ASCII: %d\n", i);
    
    return 0;
}
